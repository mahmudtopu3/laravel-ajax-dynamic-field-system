 <?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit User Data</h1>
    </div>

    <!-- Content Row -->
    


    
    <div class="row">
    <div class="col-md-12">

    <?php if($message = Session::get('success')): ?>

<div class="alert alert-success">

    <p><?php echo e($message); ?></p>

</div>

<?php endif; ?>
<?php if($errors->any()): ?>

<div class="alert alert-danger">

    <strong>Whoops!</strong> There were some problems with your input.<br><br>

    <ul>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

</div>

<?php endif; ?>
        <form action="<?php echo e(route('update')); ?>" method="post" >
           
            <?php echo e(csrf_field()); ?>

            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="t_name">Name:</label>
                        <input type="hidden" name="id" value="<?php echo e($data->id); ?>" required>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($data->name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($data->email); ?>" required>
                    </div>
                
                  
                 
                </div>

                <div class="col-md-6">
                    
                    <div class="form-group">
                        <label for="type">Admin Status:</label>
                        <select name="type" class="form-control" id="type">
                            <option value="" >Select One</option>
                            
                            <option value="admin" <?php if($data->type=="admin"){ echo "selected='selected'";}?>  >Admin</option>
                            <option value="user" <?php if($data->type=="user"){ echo "selected='selected'";}?>>User</option>
                        </select>

                    </div>

                    <div class="form-group">
                        <label for="approve_status">Approval Status:</label>
                        <select name="approve_status" class="form-control" id="approve_status">
                                <option value="" >Select One</option>        
                                <option value="1" <?php if($data->approve_status==1){ echo "selected='selected'";}?>  >Approved</option>
                                <option value="0" <?php if($data->approve_status==0){ echo "selected='selected'";}?>>Pending</option>
                        </select>

                    </div>
   

                </div>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
        </form>
     </div>
    </div>

    <!-- Content Row -->

    <div class="row"></div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>