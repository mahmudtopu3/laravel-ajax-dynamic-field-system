<title>Information From Data1</title>
<?php $__env->startSection('content'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">List of Entries</h1>
            <hr>
          </div>

          
          

          <!-- Content Row -->

                 <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Information From Data1</h6>
            </div>
            <?php if($message = Session::get('success')): ?>

              <div class="alert alert-success">

                  <p><?php echo e($message); ?></p>

              </div>

              <?php endif; ?>
              <?php if($errors->any()): ?>

              <div class="alert alert-danger">

                  <strong>Whoops!</strong> There were some problems with your input.<br><br>

                  <ul>

                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <li><?php echo e($error); ?></li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>

              </div>

              <?php endif; ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>ID</th>  
                      <th>Name</th>
                      <th>Country</th>
                      <th>District</th>
                      <th>Address</th>
                      <th>Image</th>
                    
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>ID</th>  
                      <th>Name</th>
                      <th>Country</th>
                      <th>District</th>
                      <th>Address</th>
                      <th >Image</th>
                    </tr>
                  </tfoot>
                  <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td><?php echo e($value->id); ?></td>
                      <td><?php echo e($value->name); ?></td>
                      <td><?php echo e($value->country); ?></td>
                      <td><?php echo e($value->district); ?></td>
                      <td><?php echo e($value->address); ?></td>
                      <td> <img src="<?php echo e(URL::to('/')); ?>/public/images/<?php echo e($value->image); ?>" alt="Image Not Found" width="300px" height="150px" class="img img-responsive">
                          
                      </td>
                 
                     

              
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                   
                  </tbody>
                </table>
              </div>
            </div>
          </div>
           </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


   
  <?php $__env->stopSection(); ?>
  <?php $__env->startPush('scripts'); ?>
   <script src="<?php echo e(asset('adminvendor/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('adminvendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('adminjs/demo/datatables-demo.js')); ?>"></script>
 
  
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>